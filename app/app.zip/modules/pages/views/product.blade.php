@extends(Helper::layout())


@section('style')
    <link rel="stylesheet" href="css/fotorama.css">
@stop


@section('content')
        <main class="product">
            <section class="section-cont">
                <ul class="rec-filter">
                    <li class="rec-filter-li active">
                        <a href="#">Брикеты</a>
                    <li class="rec-filter-li">
                        <a href="#">Классическая коллекция</a>
                    <li class="rec-filter-li">
                        <a href="#">Лучшие десерты</a>
                    <li class="rec-filter-li">
                        <a href="#">Стаканчик, трубочка, эскимо</a>
                </ul>
                <div class="fotorama" data-auto="false">
                    <div class="slide">
                        <img src="img/products/01.png">
                        <h2>Шоколадное с шоколадным соусом</h2>
                        <div class='product-desc'>Для истинных любителей шоколада!</div>
                    </div>
                    <div class="slide">
                        <img src="img/products/01.png">
                        <h2>Шоколадное с шоколадным соусом</h2>
                        <div class='product-desc'>Для истинных любителей шоколада!</div>
                    </div>
                    <div class="slide">
                        <img src="img/products/01.png">
                        <h2>Шоколадное с шоколадным соусом</h2>
                        <div class='product-desc'>Для истинных любителей шоколада!</div>
                    </div>                    
                </div>
            </section>
        </main>
@stop


@section('scripts')
        {{ HTML::script("js/vendor/fotorama.js") }}
        <script>
            $(function () {
                $('.fotorama').fotorama({
                    width: '100%',
                    height: '511',
                    nav: false
                });
            });
        </script>
@stop
