<?php

class Module extends Eloquent {
	
	protected $guarded = array();

	protected $table = 'modules';

}