<?php 

return array(

	'users' => 'Module users',
	'seo' => 'Search engine optimization (SEO)',
	'pages' => 'Content management',
	'catalogs' => 'Module catalog',
	'galleries' => 'Albums and galleries',
	'languages' => 'Multilanguage',
	'news' => 'News',
	'articles' => 'Articles',
	'templates' => 'Templates',
	'downloads' => 'Module downloads',
);