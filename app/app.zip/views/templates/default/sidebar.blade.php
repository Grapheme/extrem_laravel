<aside class="aside col-xs-2 col-sm-2 col-md-2 col-lg-2">
	<h2 class="aside-header">Магазин монет</h2>
	<ul class="aside-list list-unstyled">
		<li class="aside-item"><a href="#">Австралия и Океания(19099)</a></li>
		<li class="aside-item"><a href="#">Азия(60000)</a></li>
		<li class="aside-item"><a href="#">Аксессуары и литература(8990)</a></li>
		<li class="aside-item"><a href="#">Америка(65353)</a></li>
		<li class="aside-item"><a href="#">Античные(6035)</a></li>
		<li class="aside-item"><a href="#">Африка(38402)</a></li>
		<li class="aside-item"><a href="#">Велибритания(20938)</a></li>
		<li class="aside-item"><a href="#">Германия и Австрия(48063)</a></li>
		<li class="aside-item"><a href="#">Европа(154038)</a></li>
		<li class="aside-item"><a href="#">Золотая Орда(2693)</a></li>
		<li class="aside-item"><a href="#">Золотые инвестиционные монеты(199)</a></li>
		<li class="aside-item"><a href="#">Россия до 1917 года(114464)</a></li>
		<li class="aside-item"><a href="#">Россия и СССР 1917-1991 года(119302)</a></li>
		<li class="aside-item"><a href="#">Россия после 1991 года(90575)</a></li>
		<li class="aside-item"><a href="#">Специальные выпуски, коллекции(5987)</a></li>
		<li class="aside-item"><a href="#">Страны СНГ и Балтии(19203)</a></li>
		<li class="aside-item"><a href="#">Копии, реплики(10809)</a></li>
		<li class="aside-item"><a href="#">Платежные жетоны(1881)</a></li>
		<li class="aside-item"><a href="#">Сувенирные монеты(766)</a></li>
		<li class="aside-item"><a href="#">Разное в монетах</a></li>
	</ul>
	<h2 class="aside-header">Каталог монет</h2>
	<ul class="aside-list list-unstyled">
		<li class="aside-item"><a href="#">Наборы монет</a></li>
		<li class="aside-item"><a href="#">Банкноты</a></li>
		<li class="aside-item"><a href="#">Подарочные наборы</a></li>
		<li class="aside-item"><a href="#">Аксессуары</a></li>
		<li class="aside-item"><a href="#">Металлоискатели</a></li>
		<li class="aside-item"><a href="#">Программа нумизмата</a></li>
		<li class="aside-item"><a href="#">Приложния для смартфона</a></li>
	</ul>
	<h2 class="aside-header">Аукцион монет</h2>
	<ul class="aside-list list-unstyled">
		<li class="aside-item"><a href="#">Аукцион монет</a></li>
		<li class="aside-item"><a href="#">Правила аукциона</a></li>
	</ul>
	<h2 class="aside-header">Нумизмату</h2>
	<ul class="aside-list list-unstyled">
		<li class="aside-item"><a href="#">Главная</a></li>
		<li class="aside-item"><a href="#">Новости нумизматики</a></li>
		<li class="aside-item"><a href="#">Канал новостей</a></li>
		<li class="aside-item"><a href="#">Библиотека нумизмата</a></li>
		<li class="aside-item"><a href="#">Клуб Нумизмат</a></li>
		<li class="aside-item"><a href="#">Регистрация</a></li>
		<li class="aside-item"><a href="#">Форум нумизматов</a></li>
		<li class="aside-item"><a href="#">Архив форума</a></li>
		<li class="aside-item"><a href="#">Черный список</a></li>
		<li class="aside-item"><a href="#">Форум кладоискателей</a></li>
		<li class="aside-item"><a href="#">Объявления пользователей</a></li>
		<li class="aside-item"><a href="#">Нужны монеты</a></li>
		<li class="aside-item"><a href="#">New ценник на монеты</a></li>
		<li class="aside-item"><a href="#">Стоимость монет</a></li>
		<li class="aside-item"><a href="#">Нумизматический чат</a></li>
		<li class="aside-item"><a href="#">Распознавание монет</a></li>
		<li class="aside-item"><a href="#">Юбилейные монеты</a></li>
		<li class="aside-item"><a href="#">Монета, история</a></li>
		<li class="aside-item"><a href="#">Подписка</a></li>
		<li class="aside-item"><a href="#">Видео для нумизматов</a></li>
		<li class="aside-item"><a href="#">Игровой раздел</a></li>
		<li class="aside-item"><a href="#">Антиквариат</a></li>
		<li class="aside-item"><a href="#">Золотой червонец</a></li>
		<li class="aside-item"><a href="#">Антикварное обозрение</a></li>
	</ul>
</aside>