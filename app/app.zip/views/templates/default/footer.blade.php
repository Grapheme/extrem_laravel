<footer class="footer">

    <div style="text-align:center; font-size:24px; background-color:#eee; height:100%;">
        Футер
    </div>

</footer>