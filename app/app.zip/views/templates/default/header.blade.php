<header class="header">

    <div style="text-align:center; font-size:24px; background-color:#eee; height:100%;">
        <h2 style="margin: 10px auto">Хедер</h2>
        <a href="/">В начало</a> | 
        <a href="/feedback">Обратная связь</a>
    </div>

</header>