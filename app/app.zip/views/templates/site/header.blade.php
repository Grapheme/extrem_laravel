        <header class="header">
            <h1 class="logo">
                <a href="#">48 копеек</a>
            </h1>
            <nav>
                <ul class="nav-ul">
                    <li class="nav-li active">
                        <a href="/">О проекте</a>
                    <li class="nav-li">
                        <a href="/product">Продукция</a>
                    <li class="nav-li">
                        <a id="feedback" href="">Обратная связь</a>
                    <li class="nav-li">
                        <a id="login" href="">Войти</a>
                </ul>
            </nav>
        </header>